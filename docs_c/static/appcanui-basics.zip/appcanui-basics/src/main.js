import App from './App'
import appcanui from 'appcanui-we'
import HelloAppCanUI from '@/pages/hello.vue'
import navigator from '@/pages/navigator.vue'


let op = {
  el: '#app',
  render: v => v(App),
  routes: [
    {
      path: '/',
      name: 'AppCanUI',
      component: HelloAppCanUI
    },
    {
      path: '/navigator',
      name: 'navigator',
      component: navigator
    },
  ],
  config: {
    window: {
      navigationBarTitleText: 'AppCan 官方组件展示',
      navigationBarBackgroundColor: '#FAFAFA',
      navigationBarTextStyle: '#3b3b3b'
    },
    tabbar: {
      color: '#7A7E83',
      selectedColor: '#0074E8',
      borderStyle: 'black',
      backgroudColor: '#ffffff',
      list: [
        {
          pagePath: '/',
          iconPath: 'home',
          selecedIconPath: 'home',
          text: '组件'
        },
        {
          pagePath: '/ACAPI',
          iconPath: 'ucenter-outline',
          selecedIconPath: 'ucenter-outline',
          text: '接口'
        }
      ]
    }
  }

}

appcanui.start(op)