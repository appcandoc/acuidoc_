<template>
  <ac-layout>
    <ac-navigator
      url="/?state=1&bb=2&ccc=222"
      openType="navigate"
      hover-class="navigator-hover"
    >
      <ac-button type="default">跳转到新页面</ac-button>
    </ac-navigator>
  </ac-layout>
</template>

<script>
export default {
  config: {
    navigationBarTitleText: "navigator"
  },
  name: "navigator",
  data() {
    return {};
  },
  methods: {}
};
</script>

<style lang="less">
</style>
