<template>
    <ac-layout>
        路由传递过来的参数： {{urlParams}}
        <ac-button :class="[$style.button, $style.buttonClose]">X</ac-button>
        <ac-image src="../../static/120.png" width="200" height="200"></ac-image>
    </ac-layout>
</template>

<script>

    export default {
        config: {
            "navigationBarTitleText": "AppCanUI"
        },
        name: 'AppCanUI',
        data() {
            return {
                urlParams:'',
            }
        },
        methods: {
        },
        created(){
            this.urlParams = JSON.stringify(appcan.getUrlQuery())
        },
    }

</script>

<style module>
.button {
  border: none;
  border-radius: 2px;
}

.buttonClose {
  background-color: red;
}
</style>
